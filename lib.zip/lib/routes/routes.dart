// ignore_for_file: constant_identifier_names

abstract class Rutas {
  static const SPLASH = "/";
  static const LOGIN = "/login";
  static const REGISTER = "/register";
  static const HOME = "/home";
}