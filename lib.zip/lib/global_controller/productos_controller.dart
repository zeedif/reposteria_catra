import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_meedu/meedu.dart';
import 'package:reposteria_catra/domain/models/productos.dart';

class ProductosServices extends SimpleNotifier {
  FirebaseFirestore? _instance;
  List<Productos> _pasteles = [];
  List<Productos> _brownies = [];
  List<Productos> _galletas = [];

  List<Productos> getPasteles() {
    return _pasteles;
  }

  List<Productos> getBrownies() {
    return _brownies;
  }

  List<Productos> getGalletas() {
    return _galletas;
  }

  Future<void> getPastelesCollectionFromFirestore() async {
    _instance = FirebaseFirestore.instance;
    CollectionReference pasteles = _instance!.collection('productos');
    DocumentSnapshot snapshot = await pasteles.doc('pasteles').get();
    var data = snapshot.data() as Map;
    data.forEach((key, value) {
      _pasteles.add(Productos.fromJSON(value));
    });
    notify();
  }

  Future<void> getGalletasCollectionFromFirestore() async {
    _instance = FirebaseFirestore.instance;
    CollectionReference galletas = _instance!.collection('productos');
    DocumentSnapshot snapshot = await galletas.doc('galletas').get();
    var data = snapshot.data() as Map;
    data.forEach((key, value) {
      _galletas.add(Productos.fromJSON(value));
    });
    notify();
  }

  Future<void> getBrowniesCollectionFromFirestore() async {
    _instance = FirebaseFirestore.instance;
    CollectionReference brownies = _instance!.collection('productos');
    DocumentSnapshot snapshot = await brownies.doc('brownies').get();
    var data = snapshot.data() as Map;
    data.forEach((key, value) {
      _brownies.add(Productos.fromJSON(value));
    });
    notify();
  }

  void resetProductosToDefaults() {
    _pasteles.clear();
    _galletas.clear();
    _brownies.clear();
  }
}

final productosProvider = SimpleProvider(
  (_) => ProductosServices(),
  autoDispose: false,
);
