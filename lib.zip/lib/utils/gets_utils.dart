import 'package:flutter/material.dart';
import 'package:reposteria_catra/domain/models/categorias.dart';

class GetUtils{
  static List<Categorias> getCategories(){
    return [
      Categorias(
        color: Colors.amber,
        name: "Pastel",
        imgName: "cat1"
      ),
      Categorias(
        color: Colors.amber,
        name: "Brownies",
        imgName: "cat2"
      ),
      Categorias(
        color: Colors.amber,
        name: "Galletas",
        imgName: "cat3"
      )
    ];
  }
}