import 'dart:ui';

class Categorias {
  String name;
  Color color;
  String imgName;

  Categorias({
    required this.name,
    required this.color,
    required this.imgName
  });
}