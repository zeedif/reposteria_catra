class Productos {
  String name;
  double precio;
  String img;
  String sabor;
  int estado;
  bool isSelected;
  Productos(
      {required this.name,
      required this.precio,
      required this.img,
      required this.sabor,
      required this.estado,
      required this.isSelected});
  factory Productos.fromJSON(Map<String, dynamic> json) {
    return Productos(
      name: json['nombre'],
      precio: json['precio'].toDouble(),
      img: json['img'],
      sabor: json['sabor'],
      estado: json['estado'].toInt(),
      isSelected: false
    );
  }
}
